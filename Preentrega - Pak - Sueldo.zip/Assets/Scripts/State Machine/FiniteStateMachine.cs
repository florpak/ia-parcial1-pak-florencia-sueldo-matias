using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FiniteStateMachine
{
    Dictionary<PlayerState, State> allStates = new Dictionary<PlayerState, State>();
    Transform transform;
    float size;
    float _maxSpeed;
    float viewRadius;
    LayerMask obstacleLayer;
    Vector3 velocity;
    State _currentState;
    float _maxForce;
    public FiniteStateMachine(Transform transform, float size, float _maxSpeed, float viewRadius, LayerMask obstacleLayer, Vector3 velocity, float _maxForce)
    {
        this.transform = transform;
        this.size = size;
        this._maxSpeed = _maxSpeed;
        this.viewRadius = viewRadius;
        this.obstacleLayer = obstacleLayer;
        this.velocity = velocity;
        this._maxForce = _maxForce;
    }

    public void AddState(PlayerState playerState, State state)
    {

        if (!allStates.ContainsKey(playerState))
        {
            allStates.Add(playerState, state);
        }
        else
        {
            allStates[playerState] = state;
        }
    }

    public void Update()
    {
        _currentState.OnUpdate();
    }

    public void ChangeState(PlayerState state, Vector3 target, float velocity)
    {
        _currentState?.OnExit();
        if (!HasToUseObstacleAvoidance())
        {
            if (allStates.ContainsKey(PlayerState.Move)) _currentState = allStates[PlayerState.Move];
        }
        else
        {
            if (allStates.ContainsKey(state)) _currentState = allStates[state];
        }
        _currentState?.OnEnter(target);
    }

    public bool HasToUseObstacleAvoidance()
    {
        Vector3 avoidance = ObstacleAvoidance();
        avoidance.y = 0;
        AddForce(avoidance * 2);
        return avoidance != Vector3.zero;
    }
    public Vector3 ObstacleAvoidance()
    {
        /*Debug.DrawLine(transform.position, transform.position + transform.forward * viewRadius);
        if (Physics.Raycast(transform.position, transform.forward, viewRadius,obstacleLayer))
        {
            return Seek(transform.forward, _maxSpeed);
        }*/

        Debug.DrawLine(transform.position + transform.right * size, transform.position + transform.right * size + transform.forward * viewRadius, Color.green);
        Debug.DrawLine(transform.position - transform.right * size, transform.position - transform.right * size + transform.forward * viewRadius, Color.green);

        if (Physics.Raycast(transform.position + transform.right * size, transform.forward, viewRadius, obstacleLayer))
        {
            Debug.DrawLine(transform.position, transform.up - transform.right * _maxSpeed, Color.red);
            return Seek(transform.up - transform.right * 4, _maxSpeed);
        }
        else if (Physics.Raycast(transform.position - transform.right * size, transform.forward, viewRadius, obstacleLayer))
        {
            Debug.DrawLine(transform.position, transform.up + transform.right * _maxSpeed, Color.magenta);
            return Seek(transform.up + transform.right, _maxSpeed);
        }


        return Vector3.zero;
    }
    public Vector3 Seek(Vector3 targetPos, float maxSpeed)
    {
        Debug.DrawLine(transform.position, targetPos, Color.yellow);
        Vector3 vectorDeseado = targetPos - transform.position;
        Debug.DrawLine(transform.position, targetPos - transform.position, Color.white);

        vectorDeseado.Normalize();
        vectorDeseado *= maxSpeed;

        Vector3 steering = vectorDeseado - velocity;
        steering = Vector3.ClampMagnitude(steering, _maxForce * Time.deltaTime);


        return steering;

    }
    public void AddForce(Vector3 force)
    {
        velocity = Vector3.ClampMagnitude(force + velocity, _maxSpeed);
    }
}


public enum PlayerState
{
    Idle, Move, Attack
}
