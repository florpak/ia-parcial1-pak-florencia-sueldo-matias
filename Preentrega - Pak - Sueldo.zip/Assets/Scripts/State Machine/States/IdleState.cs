using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IdleState : State
{
    public override void OnEnter(Vector3 target)
    {
        Debug.Log("Entro al idle");
    }

    public override void OnExit()
    {
        Debug.Log("Salgo del idle");
    }

    public override void OnUpdate()
    {
        Debug.Log("estoy en idle");
    }

}
