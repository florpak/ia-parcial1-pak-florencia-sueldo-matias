using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    private FiniteStateMachine fsm;
    [SerializeField] protected float size = 1f;
    [SerializeField] protected float _maxSpeed;
    [SerializeField] protected float viewRadius;
    [SerializeField] public Vector3 velocity;
    [SerializeField] protected LayerMask obstacleLayer;
    List<Agent> boidsList;
    [SerializeField]
    protected float _maxForce;
    [SerializeField]
    protected Agent targetAgent;

    // Start is called before the first frame update
    void Start()
    {
         size = 1f;
        //GameManager.Instance.enemyAgent.Add(this);
        fsm = new FiniteStateMachine(transform, size, _maxSpeed, viewRadius, obstacleLayer, velocity, _maxForce);
        fsm.AddState(PlayerState.Idle, new IdleState());
        fsm.ChangeState(PlayerState.Idle,transform.position,0);
        boidsList = GameManager.Instance.agents;
    }

    // Update is called once per frame
    void Update()
    {
        fsm.Update();

    }

    private void UpdateToChase()
    {
        foreach (Boid item in boidsList)
        {
            /*if (Vector3.Distance(transform.position,item.transform.position< viewRadius){
                fsm.ChangeState(PlayerState.Attack,);
            })*/
        }
       
    }


}
