#Parcial 1 - Inteligencia Artificial I
Alumnos: Pak Florencia, Sueldo Matías
